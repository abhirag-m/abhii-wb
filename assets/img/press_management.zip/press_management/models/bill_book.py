from email.policy import default

from odoo import models, fields, api
from odoo.exceptions import ValidationError
import logging
_logger = logging.getLogger(__name__)




class BillBookPage(models.Model):
    _name = 'printing.bill.book.page'
    _description = 'Bill Book Page'

    customer_id = fields.Many2one('res.partner', string="Customer", required=True)
    num_copies = fields.Integer(string="Number of Copies", required=True,default=2)
    number_of_books = fields.Integer(string='Number of Books', required=True)
    receipts_per_book = fields.Integer(string='Receipts Per Book', required=True)
    designing_charge = fields.Float(string="Designing Charge", required=True)
    printing_charge = fields.Float(string="Printing Charge", required=True)
    binding_charge = fields.Float(string="Binding Charge", required=True)
    numbering_charge = fields.Float(string="Numbering Charge", required=True)
    material_cost = fields.Float(string='Material Cost', compute='_compute_material_cost', store=True)
    total_cost = fields.Float(string='Total Cost', compute='_compute_total_cost', store=True)
    order_date = fields.Date(string='Order Date', default=fields.Date.context_today)
    due_date = fields.Date(string='Due Date', required=True)

    paper_type_ids = fields.Many2many('printing.paper', string="Paper Types", required=True)
    output_size_id = fields.Many2one('printing.paper.size', string="Receipt Size", required=True,
                                     default=lambda self: self._get_default_paper_size())

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', default='draft', track_visibility='onchange')

    @api.model
    def _get_default_paper_size(self):
        paper_size = self.env['printing.paper.size'].search([('name', '=', 'A4')], limit=1)
        if paper_size:
            return paper_size.id
        return False

    @api.depends('material_cost', 'designing_charge', 'printing_charge', 'binding_charge', 'numbering_charge')
    def _compute_total_cost(self):
        #Compute the total cost including material, designing, printing, binding, and numbering charges.
        for record in self:
            record.total_cost = (
                record.material_cost
                + record.designing_charge
                + record.printing_charge
                + record.binding_charge
                + record.numbering_charge
            )

    @api.constrains('num_copies', 'number_of_books', 'receipts_per_book')
    def _check_positive_values(self):
        #Ensure critical fields have positive values.
        for record in self:
            if record.num_copies <= 0:
                raise ValidationError("Number of Copies must be greater than zero.")
            if record.number_of_books <= 0:
                raise ValidationError("Number of Books must be greater than zero.")
            if record.receipts_per_book <= 0:
                raise ValidationError("Receipts Per Book must be greater than zero.")

    @api.depends('paper_type_ids', 'num_copies', 'receipts_per_book', 'output_size_id')
    def _compute_material_cost(self):
        """
        Compute the material cost based on paper types, number of copies, and receipt size.
        """
        for record in self:
            if not record.paper_type_ids:
                record.material_cost = 0.0  # If no paper types are selected, set material cost to 0
                continue

            total_material_cost = 0
            total_receipts = record.num_copies * record.number_of_books * record.receipts_per_book

            # Ensure there is at least one paper type selected
            receipts_per_type = total_receipts / len(record.paper_type_ids) if len(record.paper_type_ids) > 0 else 0

            for paper in record.paper_type_ids:
                # Search for the PaperOutputCalculator entry for the current paper and output size
                paper_output = self.env['paper.output.calculator'].search([
                    ('paper_id', '=', paper.id),
                    ('output_size_id', '=', record.output_size_id.id)
                ], limit=1)

                print(paper_output)
                # Log paper_id and output_size_id to debug missing values
                _logger.info(
                    f"Trying to find PaperOutputCalculator for paper {paper.name} (ID: {paper.id}) and output size {record.output_size_id.name} (ID: {record.output_size_id.id})")

                # If no matching PaperOutputCalculator found, create it automatically
                if not paper_output:
                    if not paper.id or not record.output_size_id.id:
                        _logger.error(
                            f"Paper ID or Output Size ID is missing for paper {paper.name} and output size {record.output_size_id.name}. Cannot create PaperOutputCalculator.")
                        continue  # Skip if either paper or output size is missing

                    _logger.warning(
                        f"No output calculator found for paper {paper.name} and output size {record.output_size_id.name}. Creating a new entry.")
                    paper_output = self.env['paper.output.calculator'].create({
                        'paper_id': paper.id,
                        'output_size_id': record.output_size_id.id,
                        'output_quantity': 1,  # You can adjust this logic as per your business requirements
                        'gsm': paper.gsm  # Adjust this as needed
                    })
                    _logger.info(
                        f"Created new output calculator for paper {paper.name} and output size {record.output_size_id.name}.")

                # Proceed with the calculation using the paper_output found or created
                output_quantity = paper_output.output_quantity

                # Prevent division by zero if output_quantity is zero
                if output_quantity == 0:
                    _logger.warning(
                        f"Output quantity is zero for paper {paper.name} and output size {record.output_size_id.name}. Skipping this paper type.")
                    continue

                # Calculate the number of sheets needed for this paper type
                sheets_needed = receipts_per_type / output_quantity
                if sheets_needed % 1 != 0:
                    sheets_needed = int(sheets_needed) + 1  # Round up if fractional sheet

                # Calculate the material cost for this paper type (using paper price)
                material_cost_for_paper = sheets_needed * paper.price
                total_material_cost += material_cost_for_paper

            # Set the calculated material cost for the record
            record.material_cost = total_material_cost


    def generate_invoice(self):
        """
        Confirms the printing order and creates an invoice linked to the partner.
        """
        for order in self:
            # Change state to confirmed
            order.state = 'confirmed'

            # Create an invoice
            invoice_vals = {
                'type': 'out_invoice',  # Customer invoice
                'partner_id': order.customer_id.id,
                'invoice_date': fields.Date.context_today(order),
                'invoice_line_ids': [(0, 0, {
                    'name': f'Printing Order {order.name}',
                    'quantity': 1,
                    'price_unit': order.total_cost,
                })],
            }
            invoice = self.env['account.move'].create(invoice_vals)

            # Link the invoice to the order
            order.invoice_id = invoice.id

            # Optionally, post the invoice immediately
            invoice.action_post()

            # Log the invoice creation in partner chatter
            if order.customer_id:
                message = f"An invoice has been created for Printing Order {order.name}."
                order.customer_id.message_post(body=message)

