from odoo import models,fields,api




class PrintingOrder(models.Model):
    _name = 'printing.order'
    _description = 'Printing Order'

    name = fields.Char(string='Order Reference', required=True, copy=False, readonly=True, default=lambda self:('New'))
    customer_id = fields.Many2one('res.partner', string='Customer', required=True)
    order_date = fields.Date(string='Order Date', default=fields.Date.context_today)
    due_date = fields.Date(string='Due Date', required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', default='draft', track_visibility='onchange')
    order_line_ids = fields.One2many('printing.order.line', 'order_ids', string='Order Lines')
    total_cost = fields.Float(string='Total Cost', compute='_compute_total_cost', store=True)
    invoice_id = fields.Many2one('account.move', string='Invoice', readonly=True)

    # Invoice Generation
    def generate_invoice(self):
        """
        Confirms the printing order and creates an invoice linked to the partner.
        """
        for order in self:
            # Change state to confirmed
            order.state = 'confirmed'

            # Create an invoice
            invoice_vals = {
                'type': 'out_invoice',  # Customer invoice
                'partner_id': order.customer_id.id,
                'invoice_date': fields.Date.context_today(order),
                'invoice_line_ids': [(0, 0, {
                    'name': f'Printing Order {order.name}',
                    'quantity': 1,
                    'price_unit': order.total_cost,
                })],
            }
            invoice = self.env['account.move'].create(invoice_vals)

            # Link the invoice to the order
            order.invoice_id = invoice.id

            # Optionally, post the invoice immediately
            invoice.action_post()

            # Log the invoice creation in partner chatter
            if order.customer_id:
                message = f"An invoice has been created for Printing Order {order.name}."
                order.customer_id.message_post(body=message)

    def action_confirm(self):
        for order in self:
            order.state = 'confirmed'
            # Example: Log in the partner account
            if order.customer_id:
                message = f"A new printing order {order.name} has been confirmed."
                order.customer_id.message_post(body=message)
    @api.depends('order_line_ids.total_line_cost')

    def _compute_total_cost(self):
        for order in self:
            order.total_cost = sum(line.total_line_cost for line in order.order_line_ids)

    def action_confirm(self):
        self.state = 'confirmed'

    def action_done(self):
        self.state = 'done'

    def action_cancel(self):
        self.state = 'cancel'


class PrintingOrderLine(models.Model):
    _name = 'printing.order.line'
    _description = 'Printing Order Line'

    order_ids = fields.Many2one('printing.order', string='Order Reference', required=True, ondelete='cascade')
    product_id = fields.Many2one('printing.product', string='Product', required=True)
    paper_id = fields.Many2one('printing.paper', string='Paper', required=True)
    output_quantity = fields.Integer(string='Required Output Quantity', default=1, required=True)
    output_size_id = fields.Many2one(
        'printing.paper.size',
        string="Output Paper Size",
        required=True,
        help="The size of the output paper (e.g., A4, A5, A3)."
    )
    material_cost = fields.Float(string='Material Cost', compute='_compute_material_cost', store=True)

    binding_cost = fields.Float(string='Binding Cost', default=0.0)
    serial_number_cost = fields.Float(string='Serial Numbering Cost', default=0.0)
    labor_cost = fields.Float(string='Designing Cost', required=True)

    total_line_cost = fields.Float(string='Total Line Cost', compute='_compute_total_line_cost', store=True)


    @api.depends('bill_book_pages.material_cost', 'binding_cost', 'serial_number_cost', 'labor_cost')
    def _compute_material_cost(self):
        """
        Calculate total material cost based on the pages in the bill book.
        """
        for line in self:
            line.material_cost = sum(page.material_cost for page in line.bill_book_pages)

    @api.depends('output_quantity', 'paper_id', 'output_size_id')
    def _compute_material_cost(self):
        """
        Calculate material cost using pre-calculated values from paper.output.calculator.
        """
        for line in self:
            if line.paper_id and line.output_size_id:
                # Fetch outputs_per_sheet from paper.output.calculator
                calculator = self.env['paper.output.calculator'].search([
                    ('paper_id', '=', line.paper_id.id),
                    ('output_size_id', '=', line.output_size_id.id)
                ], limit=1)


                if calculator:
                    # Get the number of outputs per sheet
                    outputs_per_sheet = calculator.output_quantity
                    print('output sheet count = ',outputs_per_sheet)
                    if outputs_per_sheet > 0:
                        # Calculate the number of sheets needed (rounding up)
                        sheets_needed = -(-line.output_quantity // outputs_per_sheet)  # Ceiling division
                        price_per_sheet = line.paper_id.price_per_sheet

                        # Calculate the material cost
                        line.material_cost = sheets_needed * price_per_sheet
                    else:
                        line.material_cost = 0  # No valid outputs per sheet
                else:
                    line.material_cost = 0  # No matching calculator record found
            else:
                line.material_cost = 0  # Missing paper or output size

    @api.depends('material_cost', 'binding_cost', 'serial_number_cost', 'labor_cost')
    def _compute_total_line_cost(self):
        """
        Computes the total cost for this line, including material, labor, binding, and other charges.
        """
        for line in self:
            line.total_line_cost = (line.material_cost + line.binding_cost +
                                    line.serial_number_cost + line.labor_cost)
